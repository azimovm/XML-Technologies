function escapeXML(str) {
    return str.replace(/[<>&'"]/g, char => {
        switch (char) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
            default: return char;
        }
    });
}
function generateXML(data) {
    let xml = `<root>\n`;
    xml += `  <title>${escapeXML(data.title)}</title>\n`;
    xml += `  <description>${escapeXML(data.description)}</description>\n`;
    xml += `  <items>\n`;

    for (const item of data.items) {
        xml += `    <item>\n`;
        xml += `      <name>${escapeXML(item.name)}</name>\n`;
        xml += `      <value>${escapeXML(item.value)}</value>\n`;
        xml += `      <attribute>${escapeXML(item.attribute)}</attribute>\n`;
        xml += `    </item>\n`;
    }

    xml += `  </items>\n`;
    xml += `</root>`;
    return xml;
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('buttonGenerator').addEventListener('click', function() {
        let title = document.getElementById('title').value;
        let description = document.getElementById('description').value;
        let item1 = document.getElementById('itemFirst').value;
        let item2 = document.getElementById('itemSecond').value;
        let attribute = document.getElementById('attribute').value;
        document.getElementById('xmlOutput').style.display = 'block';

        const myData = {
            title: title,
            description: description,
            items: [
                { name: "Item1", value: item1, attribute: attribute },
                { name: "Item2", value: item2, attribute: attribute }
            ]
        };

        const xml = generateXML(myData);
        document.getElementById('xmlOutput').textContent = xml;
        console.log(xml);
    });
    document.getElementById('exportButton').addEventListener('click', function() {
        const xml = document.getElementById('xmlOutput').textContent;
        if (xml) {
            exportXML(xml, 'exportedXML.xml');
        } else {
            alert('First generate XML!');
        }
    });

});
//additional function for export the XML field if needed)
function exportXML(xmlData, fileName) {
    const blob = new Blob([xmlData], { type: 'text/xml' });
    const href = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = href;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);
}
